# AWS Cloud Formation Templates

## Templates
- [EC2 SecurityGroup and S3](#ec2-securitygroup-and-s3)

# EC2 SecurityGroup and S3
- [CloudFormation JSON Template](/templates/aws-cf-ec2-s3.json)
- Design
<img src="/templates/aws-cf-ec2-s3.png" width="50%"/>
- Architecture
<img src="/templates/aws-cf-ec2-s3-architecture.png" />

